<?php
include '../config/database.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM rations WHERE user_id = ?");
$stmt->execute([$user_id]);
$rations = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Welcome to the Dashboard</h1>
    <h2>Your Ration Details</h2>
    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Quantity</th>
                <th>Date Allotted</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rations as $ration): ?>
                <tr>
                    <td><?php echo $ration['item']; ?></td>
                    <td><?php echo $ration['quantity']; ?></td>
                    <td><?php echo $ration['date_allotted']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
