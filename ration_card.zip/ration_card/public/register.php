<?php
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $ration_card_number = $_POST['ration_card_number'];

    $stmt = $pdo->prepare("INSERT INTO users (name, email, password, ration_card_number) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $email, $password, $ration_card_number]);

    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <form method="POST" action="">
        <h2>Register</h2>
        <label for="name">Name:</label>
        <input type="text" name="name" required>
        <label for="email">Email:</label>
        <input type="email" name="email" required>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
        <label for="ration_card_number">Ration Card Number:</label>
        <input type="text" name="ration_card_number" required>
        <button type="submit">Register</button>
    </form>
</body>
</html>
